package Kaiburr.rabin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.kaiburr.rabin.Mainfile;

@SpringBootTest(classes = Mainfile.class)
class RabinApplicationTests {

	@Test
	void contextLoads() {
	}

}
